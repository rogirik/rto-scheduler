import React, { useEffect, useState } from 'react';
import { Users, Mail, Phone, MapPin, Calendar, Plus, MoreHorizontal, Loader2, Download } from 'lucide-react';
import { ApiService } from '../../../services/api';
import { ExportService } from '../../../services/exportService'; // <--- IMPORT THIS
import type { Teacher } from '../../../services/api';
import { TeacherForm } from './TeacherForm';

export const TeacherList = () => {
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingTeacher, setEditingTeacher] = useState<Teacher | undefined>(undefined);
  const [exportingId, setExportingId] = useState<string | null>(null);

  useEffect(() => { loadTeachers(); }, []);

  const loadTeachers = async () => {
    try {
      const data = await ApiService.getAll<Teacher>('teachers');
      setTeachers(data);
    } catch (err) { console.error(err); } finally { setLoading(false); }
  };

  const handleExport = async (teacher: Teacher) => {
    setExportingId(teacher.id);
    try {
      // 1. Calculate the specific schedule for this teacher
      const events = await ExportService.calculateSchedule('teacher', teacher.id);
      // 2. Generate the PDF
      ExportService.generateTrainerCalendarPDF(events, teacher.name);
    } catch (e) {
      console.error(e);
      alert('Failed to generate schedule.');
    } finally {
      setExportingId(null);
    }
  };

  if (loading) return <div className="text-center py-10"><Loader2 className="animate-spin mx-auto"/></div>;

  if (showForm) {
    return <TeacherForm initialData={editingTeacher} onBack={() => { setShowForm(false); setEditingTeacher(undefined); }} onSuccess={() => { loadTeachers(); setShowForm(false); }} />;
  }

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Staff Management</h2>
          <p className="text-slate-500">Manage trainers, assessors, and administrators</p>
        </div>
        <button onClick={() => setShowForm(true)} className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-700">
          <Plus size={20} /> Add Staff
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {teachers.map((teacher) => (
          <div key={teacher.id} className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 hover:shadow-md transition-shadow relative">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-lg" style={{ backgroundColor: teacher.color || '#3b82f6' }}>
                  {teacher.name.charAt(0)}
                </div>
                <div>
                  <h3 className="font-bold text-slate-800">{teacher.name}</h3>
                  <div className="text-xs font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full inline-block mt-1">
                    {teacher.employment_type?.replace('_', ' ').toUpperCase()}
                  </div>
                </div>
              </div>
              
              <div className="flex gap-1">
                {/* --- DOWNLOAD BUTTON --- */}
                <button 
                  onClick={() => handleExport(teacher)}
                  disabled={exportingId === teacher.id}
                  className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                  title="Download Schedule"
                >
                  {exportingId === teacher.id ? <Loader2 size={18} className="animate-spin"/> : <Download size={18} />}
                </button>
                <button onClick={() => { setEditingTeacher(teacher); setShowForm(true); }} className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                  <MoreHorizontal size={18} />
                </button>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-center gap-3 text-sm text-slate-500">
                <Mail size={16} className="text-slate-400" /> {teacher.email}
              </div>
              <div className="flex items-center gap-3 text-sm text-slate-500">
                <Phone size={16} className="text-slate-400" /> {teacher.phone || 'No phone'}
              </div>
              <div className="flex items-center gap-3 text-sm text-slate-500">
                <MapPin size={16} className="text-slate-400" /> {teacher.campus || 'Main Campus'}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};