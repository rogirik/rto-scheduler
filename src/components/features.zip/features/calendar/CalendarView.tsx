import React, { useState, useEffect, useMemo } from 'react';
// FIX: Go up 3 levels (../../../) to reach src/services and src/utils
import { ApiService } from '../../../services/api';
import { generateAllEventsForInstance } from '../../../utils/scheduler';
import { ChevronLeft, ChevronRight, Loader2 } from 'lucide-react';

const MONTH_NAMES = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
const DAYS_OF_WEEK = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

export const CalendarView = () => {
  const [loading, setLoading] = useState(true);
  const [currentDate, setCurrentDate] = useState(new Date());
  
  // Data Store
  const [events, setEvents] = useState<any[]>([]);

  useEffect(() => {
    loadCalendarData();
  }, []);

  const loadCalendarData = async () => {
    try {
      setLoading(true);
      
      // 1. Fetch ALL Raw Data needed for the calculation
      const [instances, templates, subjects, academicYears, allocations, teachers] = await Promise.all([
        ApiService.getCourseInstances(),
        ApiService.getAll('course_templates'),
        ApiService.getSubjects(),
        ApiService.getAll('academic_years'),
        ApiService.getAllocationsGlobal(),
        ApiService.getTeachers()
      ]);

      // 2. Run the Generator Engine for EACH active instance
      let allGeneratedEvents: any[] = [];

      instances.forEach((instance: any) => {
        // Find related data
        const template = templates.find((t: any) => t.id === instance.template_id);
        
        if (template) {
            // GENERATE DATES (The missing piece logic)
            const instanceEvents = generateAllEventsForInstance(
                instance, 
                academicYears as any[], 
                template as any, 
                subjects as any[], 
                teachers
            );

            // Attach Teachers to the generated events
            const hydratedEvents = instanceEvents.map(ev => {
                // Find allocation for this subject in this instance
                const allocation = allocations.find((a: any) => 
                    a.instance_id === ev.instanceId && a.subject_id === ev.subjectId
                );
                const teacher = teachers.find((t: any) => t.id === allocation?.teacher_id);
                
                return {
                    ...ev,
                    teacherName: teacher?.name || 'Unassigned',
                    color: teacher?.color || '#94a3b8'
                };
            });

            allGeneratedEvents = [...allGeneratedEvents, ...hydratedEvents];
        }
      });

      setEvents(allGeneratedEvents);

    } catch (error) {
      console.error("Calendar Load Failed", error);
    } finally {
      setLoading(false);
    }
  };

  // --- CALENDAR RENDERING LOGIC ---
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const getDaysInMonth = (y: number, m: number) => new Date(y, m + 1, 0).getDate();
  const getFirstDayOfMonth = (y: number, m: number) => {
      const day = new Date(y, m, 1).getDay();
      return day === 0 ? 6 : day - 1; // Shift so Mon=0
  };

  const daysInMonth = getDaysInMonth(year, month);
  const firstDay = getFirstDayOfMonth(year, month);
  const days = Array.from({ length: 42 }, (_, i) => {
      const dayNum = i - firstDay + 1;
      if (dayNum > 0 && dayNum <= daysInMonth) return dayNum;
      return null;
  });

  const handlePrev = () => setCurrentDate(new Date(year, month - 1, 1));
  const handleNext = () => setCurrentDate(new Date(year, month + 1, 1));

  if (loading) return <div className="h-full flex items-center justify-center"><Loader2 className="animate-spin text-slate-400" /></div>;

  return (
    <div className="p-8 h-full flex flex-col bg-slate-50">
      
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-slate-800">
            {MONTH_NAMES[month]} {year}
        </h1>
        <div className="flex gap-2">
            <button onClick={handlePrev} className="p-2 bg-white border rounded hover:bg-slate-50"><ChevronLeft /></button>
            <button onClick={handleNext} className="p-2 bg-white border rounded hover:bg-slate-50"><ChevronRight /></button>
        </div>
      </div>

      {/* Grid Header */}
      <div className="grid grid-cols-7 mb-2">
        {DAYS_OF_WEEK.map(d => (
            <div key={d} className="text-center font-bold text-slate-500 text-sm uppercase">{d}</div>
        ))}
      </div>

      {/* Calendar Grid */}
      <div className="grid grid-cols-7 flex-1 gap-px bg-slate-200 border border-slate-200 rounded-lg overflow-hidden">
        {days.map((day, idx) => {
            if (!day) return <div key={idx} className="bg-slate-50/50" />;
            
            // Format Key for Filtering
            const dateKey = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
            
            // Filter events for this day
            const dayEvents = events.filter(e => {
                const eDate = e.start.toISOString().split('T')[0];
                return eDate === dateKey;
            });

            return (
                <div key={idx} className="bg-white p-2 min-h-[100px] overflow-y-auto">
                    <div className="text-sm font-bold text-slate-400 mb-1">{day}</div>
                    <div className="space-y-1">
                        {dayEvents.map((ev, i) => (
                            <div 
                                key={i} 
                                className="text-[10px] p-1 rounded text-white truncate shadow-sm cursor-pointer hover:opacity-80"
                                style={{ backgroundColor: ev.color }}
                                title={`${ev.summary} (${ev.courseName}) - ${ev.teacherName}`}
                            >
                                {ev.summary}
                            </div>
                        ))}
                    </div>
                </div>
            );
        })}
      </div>
    </div>
  );
};