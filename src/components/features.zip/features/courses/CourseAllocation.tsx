import React, { useState, useEffect } from 'react';
import { ApiService } from '../../../services/api';
import type { Teacher, CourseInstance, Course, Subject, UnitAllocation } from '../../../services/api';
import { X, Search, Wand2, RotateCcw, Check, ChevronRight, Loader2 } from 'lucide-react';

interface Props {
  instance: CourseInstance;
  onClose: () => void;
  onUpdate: () => void;
}

// RENAMED component to match your CourseList import
export const CourseAllocation: React.FC<Props> = ({ instance, onClose, onUpdate }) => {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  
  // Data State
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [allocations, setAllocations] = useState<UnitAllocation[]>([]);
  const [template, setTemplate] = useState<Course | null>(null);

  // UI State
  const [selectedUnitId, setSelectedUnitId] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    loadData();
  }, [instance]);

  const loadData = async () => {
    try {
      setLoading(true);

      // 1. Fetch Basic Data
      const [allTeachers, allAllocations, allSubjects, allTemplates] = await Promise.all([
        ApiService.getTeachers(),
        ApiService.getAllocationsGlobal(),
        ApiService.getSubjects(),
        ApiService.getAll<Course>('course_templates')
      ]);

      // 2. Find the Template for this Instance
      const myTemplate = allTemplates.find(t => t.id === instance.template_id);
      setTemplate(myTemplate || null);

      // 3. STRICT FILTER: Only show subjects that are in the Template's "sequenced_subjects" list
      if (myTemplate && myTemplate.sequenced_subjects && myTemplate.sequenced_subjects.length > 0) {
        // Filter the master list to ONLY include the IDs found in the template
        const validSubjectIds = new Set(myTemplate.sequenced_subjects);
        const filteredSubjects = allSubjects.filter(s => validSubjectIds.has(s.id));
        
        // Sort them to match the order in the template (Sequence 1, 2, 3...)
        const sortedSubjects = filteredSubjects.sort((a, b) => {
            return myTemplate.sequenced_subjects!.indexOf(a.id) - myTemplate.sequenced_subjects!.indexOf(b.id);
        });

        setSubjects(sortedSubjects);
      } else {
        // If template has no subjects, showing NOTHING is better than showing everything.
        setSubjects([]);
      }

      setTeachers(allTeachers);
      setAllocations(allAllocations.filter(a => a.instance_id === instance.id));

    } catch (error) {
      console.error("Failed to load allocator", error);
    } finally {
      setLoading(false);
    }
  };

  const handleAssign = async (teacherId: string) => {
    if (!selectedUnitId) return;
    setSaving(true);
    try {
      // Check if already assigned
      const existing = allocations.find(a => a.subject_id === selectedUnitId);
      
      const payload = {
        id: existing?.id,
        instance_id: instance.id,
        subject_id: selectedUnitId,
        teacher_id: teacherId
      };

      await ApiService.saveAllocation(payload);
      
      // Update local state immediately
      const updatedAllocations = await ApiService.getAllocationsGlobal();
      setAllocations(updatedAllocations.filter(a => a.instance_id === instance.id));
      
      onUpdate(); 
    } catch (e) {
      alert("Failed to assign teacher.");
    } finally {
      setSaving(false);
    }
  };

  const handleAutoAllocate = async () => {
    if (!confirm("Auto-Allocate will attempt to find the best teacher for unassigned units. Continue?")) return;
    
    setSaving(true);
    try {
        const newAllocations = [...allocations];
        
        for (const subject of subjects) {
            const isAssigned = newAllocations.some(a => a.subject_id === subject.id);
            if (!isAssigned) {
                // Find a random teacher for now (Simple logic)
                const randomTeacher = teachers[Math.floor(Math.random() * teachers.length)];
                if (randomTeacher) {
                    await ApiService.saveAllocation({
                        instance_id: instance.id,
                        subject_id: subject.id,
                        teacher_id: randomTeacher.id
                    });
                }
            }
        }
        
        // Refresh
        await loadData();
        onUpdate();
    } catch (e) {
        alert("Auto-allocation failed.");
    } finally {
        setSaving(false);
    }
  };

  const handleClearAll = async () => {
    if (!confirm("Remove ALL teachers from this course?")) return;
    setSaving(true);
    try {
        const toDelete = allocations.map(a => ApiService.delete('course_unit_allocations', a.id));
        await Promise.all(toDelete);
        
        setAllocations([]);
        onUpdate();
    } catch (e) {
        alert("Failed to clear.");
    } finally {
        setSaving(false);
    }
  };

  const filteredTeachers = teachers.filter(t => 
    t.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-5xl h-[80vh] flex flex-col overflow-hidden">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center bg-slate-50">
          <div>
            <h2 className="text-xl font-bold text-slate-800">Assign Teachers: {instance.name}</h2>
            <p className="text-sm text-slate-500">Select a unit on the right, then click a teacher to assign.</p>
          </div>
          <div className="flex gap-3">
             <button 
                onClick={handleClearAll}
                disabled={saving}
                className="px-4 py-2 bg-white border border-slate-200 text-slate-600 rounded-lg hover:bg-slate-50 font-bold flex items-center gap-2"
             >
                <RotateCcw size={16} /> Clear All
             </button>
             <button 
                onClick={handleAutoAllocate}
                disabled={saving}
                className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 font-bold flex items-center gap-2 shadow-sm"
             >
                {saving ? <Loader2 className="animate-spin" size={16} /> : <Wand2 size={16} />}
                Auto-Allocate
             </button>
             <button onClick={onClose} className="text-slate-400 hover:text-slate-600 ml-4">
                <X size={28} />
             </button>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex flex-1 overflow-hidden">
            
            {/* LEFT: Teacher List */}
            <div className="w-1/3 border-r border-slate-100 bg-slate-50 flex flex-col">
                <div className="p-4 border-b border-slate-200">
                    <div className="relative">
                        <Search className="absolute left-3 top-2.5 text-slate-400" size={18} />
                        <input 
                            placeholder="Search teachers..." 
                            className="w-full pl-10 pr-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-purple-500 outline-none"
                            value={searchTerm}
                            onChange={e => setSearchTerm(e.target.value)}
                        />
                    </div>
                </div>
                <div className="flex-1 overflow-y-auto p-4 space-y-3">
                    {filteredTeachers.map(teacher => (
                        <button
                            key={teacher.id}
                            disabled={!selectedUnitId || saving}
                            onClick={() => handleAssign(teacher.id)}
                            className={`w-full p-3 rounded-xl border text-left transition-all flex items-center gap-3 group ${
                                !selectedUnitId 
                                ? 'opacity-50 cursor-not-allowed bg-white border-slate-200' 
                                : 'bg-white border-slate-200 hover:border-purple-300 hover:shadow-md cursor-pointer'
                            }`}
                        >
                            <div 
                                className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm"
                                style={{ backgroundColor: teacher.color || '#94a3b8' }}
                            >
                                {teacher.name.charAt(0)}
                            </div>
                            <div>
                                <div className="font-bold text-slate-700">{teacher.name}</div>
                                <div className="text-[10px] font-bold text-slate-400 uppercase">{teacher.employment_type}</div>
                            </div>
                            {selectedUnitId && (
                                <ChevronRight className="ml-auto text-slate-300 group-hover:text-purple-500" size={18} />
                            )}
                        </button>
                    ))}
                </div>
            </div>

            {/* RIGHT: Unit List (From Template ONLY) */}
            <div className="w-2/3 bg-white flex flex-col">
                <div className="p-4 border-b border-slate-100 flex justify-between items-center">
                    <h3 className="font-bold text-slate-700">Course Units ({subjects.length})</h3>
                    <span className="text-xs text-slate-400 italic">Click a unit to select it</span>
                </div>
                
                <div className="flex-1 overflow-y-auto p-6 space-y-4">
                    {subjects.length === 0 ? (
                        <div className="text-center py-10 text-slate-400">
                            No subjects found in this Course Template.
                        </div>
                    ) : (
                        subjects.map((subject, idx) => {
                            const allocation = allocations.find(a => a.subject_id === subject.id);
                            const assignedTeacher = teachers.find(t => t.id === allocation?.teacher_id);
                            const isSelected = selectedUnitId === subject.id;

                            return (
                                <div 
                                    key={subject.id}
                                    onClick={() => setSelectedUnitId(subject.id)}
                                    className={`p-4 rounded-xl border-2 transition-all cursor-pointer flex justify-between items-center ${
                                        isSelected 
                                        ? 'border-purple-600 bg-purple-50 shadow-sm' 
                                        : 'border-slate-100 hover:border-slate-300 bg-white'
                                    }`}
                                >
                                    <div>
                                        <div className="text-xs font-bold text-slate-400 uppercase mb-1">Sequence {idx + 1}</div>
                                        <div className="font-bold text-slate-800 text-lg">{subject.name}</div>
                                    </div>

                                    {assignedTeacher ? (
                                        <div className="flex items-center gap-3 bg-white px-3 py-1.5 rounded-lg border border-slate-200 shadow-sm">
                                            <div 
                                                className="w-6 h-6 rounded-full flex items-center justify-center text-white text-xs font-bold"
                                                style={{ backgroundColor: assignedTeacher.color }}
                                            >
                                                {assignedTeacher.name.charAt(0)}
                                            </div>
                                            <span className="font-bold text-slate-700 text-sm">{assignedTeacher.name}</span>
                                            <Check size={16} className="text-green-500" />
                                        </div>
                                    ) : (
                                        <span className="text-slate-300 font-medium flex items-center gap-1">
                                            Unassigned <ChevronRight size={16} />
                                        </span>
                                    )}
                                </div>
                            );
                        })
                    )}
                </div>
            </div>

        </div>
      </div>
    </div>
  );
};