import React, { useState, useEffect } from 'react';
import { ApiService } from '../../../services/api';
import type { Course, CourseInstance, Subject } from '../../../services/api';
import { ArrowRight, Monitor, Users, Clock, Coffee, Loader2, Save, X } from 'lucide-react';
import { addDays, format, parseISO, addMinutes, isValid } from 'date-fns';

interface ScheduleCourseFormProps {
  template?: Course; 
  initialData?: CourseInstance | null;
  onClose: () => void;
  onSuccess: () => void;
}

const DAYS = [
  { id: 1, label: 'Mon' },
  { id: 2, label: 'Tue' },
  { id: 3, label: 'Wed' },
  { id: 4, label: 'Thu' },
  { id: 5, label: 'Fri' },
  { id: 6, label: 'Sat' },
  { id: 0, label: 'Sun' },
];

export const ScheduleCourseForm = ({ template, initialData, onClose, onSuccess }: ScheduleCourseFormProps) => {
  const [loading, setLoading] = useState(false);
  
  // Safe default for total hours logic
  const totalCourseHours = template && Array.isArray(template.sequenced_subjects) 
    ? template.sequenced_subjects.reduce((sum: number, s: Subject) => sum + (s.nominal_hours || 0), 0)
    : (initialData as any)?.total_hours || 0; 

  // Initialize with SAFE defaults (empty strings, never undefined)
  const [formData, setFormData] = useState({
    name: '',
    start_date: format(new Date(), 'yyyy-MM-dd'),
    hours_per_session: 6,
    start_time: '09:00', 
    break_minutes: 30,   
    days_of_week: [1, 3] as number[],
    delivery_mode: 'Face-to-Face' as 'Face-to-Face' | 'Online' | 'Mixed'
  });

  // Load Initial Data Safely
  useEffect(() => {
    if (initialData) {
      setFormData({
        name: initialData.name || '',
        // Check if date exists before formatting to prevent crash
        start_date: initialData.start_date ? format(new Date(initialData.start_date), 'yyyy-MM-dd') : format(new Date(), 'yyyy-MM-dd'),
        hours_per_session: initialData.hours_per_session || 6,
        start_time: initialData.start_time || '09:00',
        // Handle fields that might not exist on the type yet
        break_minutes: (initialData as any).break_minutes || 30, 
        days_of_week: initialData.days_of_week || [],
        delivery_mode: (initialData as any).delivery_mode || 'Face-to-Face'
      });
    } else if (template) {
      // Set default name if creating new
      setFormData(prev => ({ ...prev, name: `${template.code} - Cohort 1` }));
    }
  }, [initialData, template]);

  const [calculatedEndDate, setCalculatedEndDate] = useState<string>('');
  const [calculatedDailyFinish, setCalculatedDailyFinish] = useState<string>('');
  const [weeksDuration, setWeeksDuration] = useState(0);

  // Calculate Dates and Daily Times
  useEffect(() => {
    if (formData.days_of_week.length === 0 || formData.hours_per_session <= 0) return;

    // 1. Calculate Course Duration (Weeks)
    const weeklyHours = Math.max(1, formData.days_of_week.length * formData.hours_per_session);
    const totalWeeks = Math.ceil(totalCourseHours / weeklyHours);
    setWeeksDuration(totalWeeks);

    // 2. Calculate End Date
    if (formData.start_date && isValid(parseISO(formData.start_date))) {
        const start = parseISO(formData.start_date);
        const end = addDays(start, totalWeeks * 7);
        setCalculatedEndDate(format(end, 'yyyy-MM-dd'));
    }

    // 3. Calculate Daily Finish Time
    if (formData.start_time) {
        const parts = formData.start_time.split(':');
        if (parts.length === 2) {
            const startHour = parseInt(parts[0], 10);
            const startMin = parseInt(parts[1], 10);
            
            if (!isNaN(startHour) && !isNaN(startMin)) {
                const startDate = new Date();
                startDate.setHours(startHour, startMin, 0);

                const sessionMinutes = (formData.hours_per_session * 60) + formData.break_minutes;
                const finishDate = addMinutes(startDate, sessionMinutes);
                
                setCalculatedDailyFinish(format(finishDate, 'h:mm a')); 
            }
        }
    }
  }, [formData, totalCourseHours]);

  const toggleDay = (dayId: number) => {
    const current = formData.days_of_week;
    if (current.includes(dayId)) {
      setFormData({ ...formData, days_of_week: current.filter(d => d !== dayId) });
    } else {
      setFormData({ ...formData, days_of_week: [...current, dayId].sort() });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      // CLEAN THE DATA: Create a payload with ONLY the fields the database expects.
      // This fixes the "Could not find 'course_code' column" error.
      const payload: any = {
          name: formData.name,
          start_date: formData.start_date,
          end_date: calculatedEndDate,
          days_of_week: formData.days_of_week,
          hours_per_session: formData.hours_per_session,
          start_time: formData.start_time,
          status: 'planned' // Ensure status is set
          // Add these back if your DB table actually has these columns:
          // delivery_mode: formData.delivery_mode, 
          // break_minutes: formData.break_minutes
      };

      if (initialData?.id) {
        payload.id = initialData.id;
        // Keep existing template_id if editing
        payload.template_id = initialData.template_id; 
      } else if (template) {
        payload.template_id = template.id;
      }

      await ApiService.saveCourseInstance(payload);
      
      onSuccess();
      onClose();
    } catch (error) {
      alert('Failed to save schedule. See console for details.');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* HEADER */}
        <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center bg-slate-50">
          <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
            {initialData ? 'Edit Schedule' : 'Schedule New Course'}
          </h2>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col flex-1 overflow-hidden">
          
          {/* Scrollable Content Area */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            
            {/* Header Info (Only if template exists) */}
            {template && (
                <div className="bg-blue-50 p-4 rounded-lg border border-blue-100 flex justify-between items-center shadow-sm">
                <div>
                    <h3 className="font-bold text-blue-900">{template.code}</h3>
                    <p className="text-sm text-blue-700 truncate max-w-[200px]">{template.name}</p>
                </div>
                <div className="text-right">
                    <span className="block text-xs uppercase font-bold text-blue-400">Total Duration</span>
                    <span className="text-xl font-bold text-blue-900">{totalCourseHours} Hrs</span>
                </div>
                </div>
            )}

            {/* Basic Details */}
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Cohort / Group Name</label>
              <input
                required
                className="w-full border border-slate-300 p-2 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                value={formData.name}
                onChange={e => setFormData({...formData, name: e.target.value})}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Start Date</label>
                <input
                  type="date"
                  required
                  className="w-full border border-slate-300 p-2 rounded-lg"
                  value={formData.start_date}
                  onChange={e => setFormData({...formData, start_date: e.target.value})}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Delivery Mode</label>
                <div className="relative">
                  <select
                    className="w-full border border-slate-300 p-2 pl-9 rounded-lg appearance-none bg-white"
                    value={formData.delivery_mode}
                    onChange={e => setFormData({...formData, delivery_mode: e.target.value as any})}
                  >
                    <option value="Face-to-Face">Face-to-Face</option>
                    <option value="Online">Online</option>
                    <option value="Mixed">Mixed / Hybrid</option>
                  </select>
                  <div className="absolute left-2.5 top-2.5 text-slate-500 pointer-events-none">
                      {formData.delivery_mode === 'Online' ? <Monitor size={16} /> : <Users size={16} />}
                  </div>
                </div>
              </div>
            </div>

            <div className="border-t border-slate-100"></div>

            {/* --- TIME SETTINGS --- */}
            <h4 className="font-bold text-slate-800 text-sm">Daily Session Timing</h4>
            <div className="grid grid-cols-3 gap-4">
                <div className="col-span-1">
                  <label className="block text-sm font-medium text-slate-700 mb-1">Start Time</label>
                  <input
                      type="time"
                      required
                      className="w-full border border-slate-300 p-2 rounded-lg"
                      value={formData.start_time}
                      onChange={e => setFormData({...formData, start_time: e.target.value})}
                  />
                </div>
                <div className="col-span-1">
                  <label className="block text-sm font-medium text-slate-700 mb-1">Class Hours</label>
                  <div className="relative">
                    <input
                        type="number"
                        required
                        min="1"
                        max="12"
                        step="0.5"
                        className="w-full border border-slate-300 p-2 pl-8 rounded-lg"
                        value={formData.hours_per_session}
                        onChange={e => setFormData({...formData, hours_per_session: Number(e.target.value)})}
                    />
                    <Clock size={14} className="absolute left-3 top-3 text-slate-400" />
                  </div>
                </div>
                <div className="col-span-1">
                  <label className="block text-sm font-medium text-slate-700 mb-1">Break (Mins)</label>
                  <div className="relative">
                    <input
                        type="number"
                        required
                        min="0"
                        step="15"
                        className="w-full border border-slate-300 p-2 pl-8 rounded-lg"
                        value={formData.break_minutes}
                        onChange={e => setFormData({...formData, break_minutes: Number(e.target.value)})}
                    />
                    <Coffee size={14} className="absolute left-3 top-3 text-slate-400" />
                  </div>
                </div>
            </div>

            {/* Calculated Daily Finish Preview */}
            <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 flex justify-between items-center text-sm">
              <span className="text-slate-500">Daily Finish Time:</span>
              <span className="font-bold text-slate-800">{calculatedDailyFinish}</span>
            </div>

            <div className="border-t border-slate-100"></div>

            {/* Frequency Picker */}
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Frequency (Days per Week)</label>
              <div className="flex gap-2">
                {DAYS.map(day => (
                  <button
                    key={day.id}
                    type="button"
                    onClick={() => toggleDay(day.id)}
                    className={`flex-1 py-2 rounded-lg text-sm font-bold border transition-all ${
                      formData.days_of_week.includes(day.id)
                        ? 'bg-blue-600 text-white border-blue-600 shadow-md'
                        : 'bg-white text-slate-500 border-slate-200 hover:border-blue-300'
                    }`}
                  >
                    {day.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Overall Schedule Preview */}
            <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
              <h4 className="text-xs font-bold text-slate-500 uppercase mb-3">Course Duration</h4>
              <div className="flex items-center justify-between">
                <div className="text-center">
                  <div className="text-xs text-slate-400 mb-1">Start</div>
                  <div className="font-bold text-slate-700">{formData.start_date}</div>
                </div>
                <ArrowRight className="text-slate-300" />
                <div className="text-center">
                  <div className="text-xs text-slate-400 mb-1">Est. Finish</div>
                  <div className="font-bold text-blue-600">{calculatedEndDate}</div>
                </div>
                <div className="border-l pl-4 ml-4">
                  <div className="text-xs text-slate-400 mb-1">Duration</div>
                  <div className="font-bold text-slate-700">~{weeksDuration} Weeks</div>
                </div>
              </div>
            </div>
          </div>

          {/* Footer Actions */}
          <div className="flex justify-end gap-3 p-4 border-t border-slate-100 bg-white">
            <button type="button" onClick={onClose} className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg">Cancel</button>
            <button 
              type="submit" 
              disabled={loading}
              className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium disabled:opacity-50 flex items-center gap-2"
            >
              {loading && <Loader2 className="animate-spin" size={16} />}
              {loading ? 'Saving...' : initialData ? 'Update Schedule' : 'Schedule Course'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};