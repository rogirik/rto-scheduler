import React, { useState, useEffect } from 'react';
import { useData } from '../../../hooks/useData';
import { ApiService } from '../../../services/api';
import { AutoAllocator } from '../../../services/AutoAllocator'; // Import Engine
import { ExportService } from '../../../services/exportService'; // <--- NEW IMPORT
import type { Course, CourseInstance } from '../../../services/api';
import { 
  GraduationCap, 
  Pencil, 
  Plus, 
  Book, 
  Calendar, 
  Users, 
  Settings, 
  Wand2, 
  CheckCircle, 
  AlertCircle,
  FileText,   // <--- NEW ICON
  Loader2     // <--- NEW ICON
} from 'lucide-react';
import { Modal } from '../../shared/Modal';
import { CourseForm } from './CourseForm';
import { ScheduleCourseForm } from './ScheduleCourseForm';
import { CourseAllocation } from './CourseAllocation';

export const CourseList = () => {
  const { data: courses, loading, refresh } = useData<Course>('course_templates');
  const [instances, setInstances] = useState<CourseInstance[]>([]);
  
  // Modals
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isScheduleOpen, setIsScheduleOpen] = useState(false);
  const [isAllocationOpen, setIsAllocationOpen] = useState(false);
  
  // Selection
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [selectedInstance, setSelectedInstance] = useState<CourseInstance | null>(null);

  // Global Allocation State
  const [isGlobalRunning, setIsGlobalRunning] = useState(false);
  const [globalResult, setGlobalResult] = useState<{success: number, failed: number} | null>(null);

  // Export State
  const [exportingId, setExportingId] = useState<string | null>(null); // <--- NEW STATE

  useEffect(() => {
    loadInstances();
  }, []);

  const loadInstances = async () => {
    try {
      const data = await ApiService.getCourseInstances();
      setInstances(data || []);
    } catch (error) {
      console.error("Failed to load instances:", error);
    }
  };

  // --- HANDLERS ---

  const handleEditTemplate = (course: Course) => {
    setSelectedCourse(course);
    setIsFormOpen(true);
  };

  const handleAddTemplate = () => {
    setSelectedCourse(null);
    setIsFormOpen(true);
  };

  const handleNewSchedule = (course: Course) => {
    setSelectedCourse(course);
    setSelectedInstance(null);
    setIsScheduleOpen(true);
  };

  const handleEditSchedule = (instance: CourseInstance) => {
    const template = courses.find(c => c.id === instance.template_id) || instance.course_templates;
    if (template) {
        setSelectedCourse(template as Course);
        setSelectedInstance(instance);
        setIsScheduleOpen(true);
    } else {
        alert("Could not find the original template for this course.");
    }
  };

  const handleAssignTeachers = (instance: CourseInstance) => {
    setSelectedInstance(instance);
    setIsAllocationOpen(true);
  };

  // --- NEW EXPORT HANDLER ---
  const handleExport = async (instance: CourseInstance) => {
    setExportingId(instance.id);
    try {
      // 1. Calculate the waterfall schedule for just this course
      const events = await ExportService.calculateSchedule('course', instance.id);
      
      // 2. Generate the PDF with the unit breakdown
      ExportService.generateCourseTimetablePDF(events, instance.name);
    } catch (e) {
      console.error(e);
      alert('Failed to generate timetable.');
    } finally {
      setExportingId(null);
    }
  };

  // --- GLOBAL MAGIC HANDLER ---
  const handleGlobalAutoAllocate = async () => {
    if (!window.confirm("This will attempt to auto-assign teachers to ALL empty units across ALL courses based on availability and rules. Continue?")) {
      return;
    }

    setIsGlobalRunning(true);
    setGlobalResult(null);

    try {
      const { proposedAllocations, stats } = await AutoAllocator.generateGlobalAllocations();

      for (const alloc of proposedAllocations) {
        await ApiService.saveAllocation(alloc);
      }

      setGlobalResult(stats);
      loadInstances(); 

      setTimeout(() => setGlobalResult(null), 5000);

    } catch (error) {
      console.error(error);
      alert("Global allocation failed. Check console.");
    } finally {
      setIsGlobalRunning(false);
    }
  };


  if (loading) return <div className="p-8 text-center text-slate-500">Loading courses...</div>;

  return (
    <div className="space-y-10">
      
      {/* HEADER SECTION WITH GLOBAL ACTIONS */}
      <div className="flex flex-col gap-4">
        {/* Result Notification */}
        {globalResult && (
          <div className="bg-green-50 border border-green-200 text-green-800 p-4 rounded-xl flex items-center gap-3 shadow-sm animate-in slide-in-from-top-2">
            <CheckCircle size={24} className="text-green-600" />
            <div>
              <p className="font-bold">Global Allocation Complete!</p>
              <p className="text-sm">Successfully assigned {globalResult.success} units. {globalResult.failed} units could not be assigned (no available teachers).</p>
            </div>
          </div>
        )}

        <div className="flex justify-between items-end">
          <div></div>
          <div className="flex gap-3">
             {/* GLOBAL MAGIC BUTTON */}
             <button 
                onClick={handleGlobalAutoAllocate}
                disabled={isGlobalRunning}
                className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors shadow-sm font-bold flex items-center gap-2 disabled:opacity-50"
             >
                {isGlobalRunning ? <Wand2 size={18} className="animate-spin" /> : <Wand2 size={18} />}
                {isGlobalRunning ? 'Optimizing Schedule...' : 'Global Auto-Allocate'}
             </button>

             <button 
              onClick={handleAddTemplate}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors shadow-sm font-medium flex items-center gap-2"
            >
              <Plus size={18} /> New Template
            </button>
          </div>
        </div>
      </div>

      {/* SECTION 1: COURSE TEMPLATES */}
      <div>
        <div className="mb-4">
          <h2 className="text-2xl font-bold text-slate-800">Qualification Templates</h2>
          <p className="text-slate-500 text-sm">Master templates for your courses</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {courses.map((course) => {
            const unitCount = Array.isArray(course.sequenced_subjects) ? course.sequenced_subjects.length : 0;
            return (
              <div key={course.id} className="bg-white p-5 rounded-xl shadow-sm border border-slate-200 hover:shadow-md transition-all group">
                <div className="flex items-start gap-4 mb-4">
                  <div className="w-10 h-10 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center">
                    <GraduationCap size={20} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-bold text-slate-800 truncate">{course.code}</h3>
                    <p className="text-sm text-slate-500 truncate">{course.name}</p>
                  </div>
                </div>
                
                <div className="flex items-center justify-between pt-4 border-t border-slate-50">
                  <span className="flex items-center gap-1.5 text-xs font-medium text-slate-600 bg-slate-100 px-2.5 py-1 rounded-full">
                    <Book size={12} /> {unitCount} Units
                  </span>
                  
                  <div className="flex gap-2">
                    <button 
                      onClick={() => handleEditTemplate(course)}
                      className="text-slate-400 hover:text-blue-600 p-1.5 hover:bg-blue-50 rounded-lg transition-colors"
                      title="Edit Template"
                    >
                      <Pencil size={16} />
                    </button>
                    <button 
                      onClick={() => handleNewSchedule(course)}
                      className="flex items-center gap-1.5 text-xs font-bold text-white bg-slate-800 hover:bg-slate-700 px-3 py-1.5 rounded-lg transition-colors shadow-sm"
                    >
                      <Calendar size={12} /> Schedule
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* SECTION 2: SCHEDULED COHORTS */}
      {instances.length > 0 && (
        <div className="border-t border-slate-200 pt-8">
          <div className="mb-6">
            <h2 className="text-2xl font-bold text-slate-800">Scheduled Cohorts</h2>
            <p className="text-slate-500 text-sm">Active and upcoming course deliveries</p>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <table className="w-full text-sm text-left">
              <thead className="bg-slate-50 text-slate-500 font-medium border-b border-slate-200">
                <tr>
                  <th className="px-6 py-3">Cohort Name</th>
                  <th className="px-6 py-3">Qualification</th>
                  <th className="px-6 py-3">Dates</th>
                  <th className="px-6 py-3">Schedule</th>
                  <th className="px-6 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {instances.map((instance) => (
                  <tr key={instance.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4 font-medium text-slate-800">
                      {instance.name}
                    </td>
                    <td className="px-6 py-4 text-slate-600">
                      {instance.course_templates?.code || 'Unknown Code'}
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex flex-col text-xs">
                        <span className="text-green-600 font-medium">Start: {instance.start_date}</span>
                        <span className="text-slate-400">End: {instance.end_date || 'TBD'}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-slate-600">
                      {instance.hours_per_session}h / session <br/>
                      <span className="text-xs text-slate-400">{instance.start_time} - {instance.delivery_mode}</span>
                    </td>
                    <td className="px-6 py-4 text-right flex items-center justify-end gap-2">
                      
                      {/* --- NEW DOWNLOAD BUTTON --- */}
                      <button 
                        onClick={() => handleExport(instance)}
                        disabled={exportingId === instance.id}
                        className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-slate-100 rounded transition-colors"
                        title="Download Timetable (PDF)"
                      >
                        {exportingId === instance.id ? <Loader2 size={16} className="animate-spin"/> : <FileText size={16} />}
                      </button>

                      <button 
                        onClick={() => handleEditSchedule(instance)}
                        className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-slate-100 rounded transition-colors"
                        title="Edit Schedule"
                      >
                        <Settings size={16} />
                      </button>

                      <button 
                        onClick={() => handleAssignTeachers(instance)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-bold bg-blue-50 text-blue-700 hover:bg-blue-100 transition-colors"
                      >
                        <Users size={14} /> Assign
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* --- MODALS --- */}
      
      <Modal 
        isOpen={isFormOpen} 
        onClose={() => setIsFormOpen(false)} 
        title={selectedCourse ? "Edit Template" : "New Template"}
      >
        <CourseForm 
          initialData={selectedCourse} 
          onClose={() => setIsFormOpen(false)} 
          onSuccess={() => {
            refresh();
            setIsFormOpen(false);
          }} 
        />
      </Modal>

      <Modal 
        isOpen={isScheduleOpen} 
        onClose={() => setIsScheduleOpen(false)} 
        title={selectedInstance ? "Edit Course Schedule" : "Schedule Course Cohort"}
      >
        {selectedCourse && (
          <ScheduleCourseForm 
            template={selectedCourse}
            initialData={selectedInstance}
            onClose={() => setIsScheduleOpen(false)} 
            onSuccess={() => {
              loadInstances(); 
              setIsScheduleOpen(false);
            }} 
          />
        )}
      </Modal>

      <Modal 
        isOpen={isAllocationOpen} 
        onClose={() => setIsAllocationOpen(false)} 
        title={selectedInstance ? `Assign Teachers: ${selectedInstance.name}` : "Manage Allocations"}
      >
        {selectedInstance && (
          <CourseAllocation 
            instance={selectedInstance}
            onClose={() => setIsAllocationOpen(false)}
          />
        )}
      </Modal>

    </div>
  );
};