import React, { useState, useEffect } from 'react';
import { ApiService } from '../../../services/api';
import { supabase } from '../../../services/supabase';
import type { Course, Subject } from '../../../services/api';
import { Search, Plus, X, Clock, GripVertical } from 'lucide-react';
// CHANGED: Added 'type' before DropResult to fix the crash
import { DragDropContext, Droppable, Draggable, type DropResult } from '@hello-pangea/dnd';

interface CourseFormProps {
  onClose: () => void;
  onSuccess: () => void;
  initialData?: Course | null;
}

export const CourseForm = ({ onClose, onSuccess, initialData }: CourseFormProps) => {
  const [loading, setLoading] = useState(false);
  const [allSubjects, setAllSubjects] = useState<Subject[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Form State
  const [formData, setFormData] = useState({
    code: '',
    name: '',
    description: '',
  });

  // The list of selected subjects for this course
  const [selectedSubjects, setSelectedSubjects] = useState<Subject[]>([]);

  // 1. Load Data
  useEffect(() => {
    const loadData = async () => {
      const subjects = await ApiService.getAll<Subject>('subjects');
      setAllSubjects(subjects);

      if (initialData) {
        setFormData({
          code: initialData.code || '',
          name: initialData.name,
          description: initialData.description || '',
        });

        if (initialData.sequenced_subjects && Array.isArray(initialData.sequenced_subjects)) {
           const linked = initialData.sequenced_subjects
             .map((savedItem: any) => subjects.find(s => s.id === savedItem.id))
             .filter(Boolean) as Subject[];
           setSelectedSubjects(linked);
        }
      }
    };
    loadData();
  }, [initialData]);

  // 2. Handlers
  const addSubject = (subject: Subject) => {
    if (!selectedSubjects.find(s => s.id === subject.id)) {
      setSelectedSubjects([...selectedSubjects, subject]);
    }
  };

  const removeSubject = (subjectId: string) => {
    setSelectedSubjects(selectedSubjects.filter(s => s.id !== subjectId));
  };

  // Drag & Drop Reorder Logic
  const onDragEnd = (result: DropResult) => {
    if (!result.destination) return;

    const items = Array.from(selectedSubjects);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);

    setSelectedSubjects(items);
  };

  const totalHours = selectedSubjects.reduce((sum, s) => sum + (s.hours || 0), 0);

  // 3. Save
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    const payload = {
      ...formData,
      sequenced_subjects: selectedSubjects 
    };

    try {
      if (initialData?.id) {
        const { error } = await supabase
          .from('course_templates')
          .update(payload)
          .eq('id', initialData.id);
        if (error) throw error;
      } else {
        await ApiService.createCourse(payload);
      }
      onSuccess();
      onClose();
    } catch (error) {
      alert('Failed to save course');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const filteredSubjects = allSubjects.filter(s => 
    !selectedSubjects.find(sel => sel.id === s.id) && 
    (s.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
     (s.description && s.description.toLowerCase().includes(searchQuery.toLowerCase())))
  );

  return (
    <form onSubmit={handleSubmit} className="h-[80vh] flex flex-col">
      <div className="flex-1 overflow-y-auto px-1 space-y-6">
        
        {/* --- DETAILS --- */}
        <div className="grid grid-cols-4 gap-4">
          <div className="col-span-1">
            <label className="block text-sm font-medium text-slate-700 mb-1">Code</label>
            <input
              required
              placeholder="TAE40122"
              className="w-full border border-slate-300 p-2 rounded-lg uppercase"
              value={formData.code}
              onChange={e => setFormData({...formData, code: e.target.value.toUpperCase()})}
            />
          </div>
          <div className="col-span-3">
            <label className="block text-sm font-medium text-slate-700 mb-1">Qualification Name</label>
            <input
              required
              placeholder="Certificate IV in Training and Assessment"
              className="w-full border border-slate-300 p-2 rounded-lg"
              value={formData.name}
              onChange={e => setFormData({...formData, name: e.target.value})}
            />
          </div>
          <div className="col-span-4">
            <label className="block text-sm font-medium text-slate-700 mb-1">Description</label>
            <textarea
              rows={2}
              className="w-full border border-slate-300 p-2 rounded-lg"
              value={formData.description}
              onChange={e => setFormData({...formData, description: e.target.value})}
            />
          </div>
        </div>

        <div className="border-t border-slate-100"></div>

        {/* --- PICKER --- */}
        <div className="grid grid-cols-2 gap-6 h-96">
          
          {/* LEFT: Search */}
          <div className="flex flex-col h-full border border-slate-200 rounded-xl overflow-hidden bg-slate-50">
            <div className="p-3 bg-white border-b border-slate-200">
              <div className="relative">
                <Search size={16} className="absolute left-3 top-2.5 text-slate-400" />
                <input 
                  className="w-full pl-9 pr-3 py-2 bg-slate-100 border-transparent focus:bg-white focus:ring-2 focus:ring-blue-500 rounded-lg text-sm transition-all"
                  placeholder="Search available units..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                />
              </div>
            </div>
            <div className="flex-1 overflow-y-auto p-2 space-y-2">
              {filteredSubjects.map(subject => (
                <button
                  key={subject.id}
                  type="button"
                  onClick={() => addSubject(subject)}
                  className="w-full text-left p-3 bg-white hover:bg-blue-50 hover:border-blue-200 border border-slate-200 rounded-lg shadow-sm transition-all group flex justify-between items-center"
                >
                  <div>
                    <div className="font-bold text-slate-700 text-sm">{subject.name}</div>
                    <div className="text-xs text-slate-500 flex items-center gap-1 mt-1">
                      <Clock size={10} /> {subject.hours} hrs
                    </div>
                  </div>
                  <Plus size={16} className="text-slate-300 group-hover:text-blue-500" />
                </button>
              ))}
              {filteredSubjects.length === 0 && (
                <div className="p-8 text-center text-slate-400 text-sm">
                  {searchQuery ? 'No matching units found' : 'All available units added'}
                </div>
              )}
            </div>
          </div>

          {/* RIGHT: Drag & Drop List */}
          <div className="flex flex-col h-full border-2 border-blue-100 rounded-xl overflow-hidden bg-white">
            <div className="p-3 bg-blue-50 border-b border-blue-100 flex justify-between items-center">
              <span className="font-bold text-blue-900 text-sm">Course Structure</span>
              <span className="text-xs bg-white text-blue-700 px-2 py-1 rounded font-bold border border-blue-200">
                {selectedSubjects.length} Units
              </span>
            </div>
            
            <DragDropContext onDragEnd={onDragEnd}>
              <Droppable droppableId="course-subjects">
                {(provided) => (
                  <div 
                    {...provided.droppableProps}
                    ref={provided.innerRef}
                    className="flex-1 overflow-y-auto p-2 space-y-2"
                  >
                    {selectedSubjects.length === 0 ? (
                      <div className="h-full flex flex-col items-center justify-center text-slate-400 text-sm p-4 text-center">
                        <p>No units selected yet.</p>
                        <p className="text-xs mt-1">Click items on the left to add them.</p>
                      </div>
                    ) : (
                      selectedSubjects.map((subject, index) => (
                        <Draggable key={subject.id} draggableId={subject.id} index={index}>
                          {(provided, snapshot) => (
                            <div
                              ref={provided.innerRef}
                              {...provided.draggableProps}
                              className={`flex items-center gap-3 p-3 bg-white border rounded-lg group transition-shadow ${
                                snapshot.isDragging ? 'shadow-lg border-blue-400 ring-1 ring-blue-400' : 'border-slate-100 shadow-sm'
                              }`}
                              style={provided.draggableProps.style}
                            >
                              <div {...provided.dragHandleProps} className="text-slate-300 hover:text-slate-500 cursor-grab active:cursor-grabbing p-1">
                                <GripVertical size={16} />
                              </div>
                              <div className="w-6 h-6 bg-slate-100 rounded-full flex items-center justify-center text-xs font-bold text-slate-500">
                                {index + 1}
                              </div>
                              <div className="flex-1">
                                <div className="font-medium text-slate-800 text-sm">{subject.name}</div>
                                <div className="text-xs text-slate-500">{subject.hours} hrs</div>
                              </div>
                              <button
                                type="button"
                                onClick={() => removeSubject(subject.id)}
                                className="text-slate-300 hover:text-red-500 p-1 rounded transition-colors"
                              >
                                <X size={16} />
                              </button>
                            </div>
                          )}
                        </Draggable>
                      ))
                    )}
                    {provided.placeholder}
                  </div>
                )}
              </Droppable>
            </DragDropContext>

            {/* Footer */}
            <div className="p-3 bg-slate-50 border-t border-slate-200 flex justify-between items-center">
              <span className="text-xs font-bold text-slate-500 uppercase">Total Duration</span>
              <span className="text-sm font-bold text-slate-800">{totalHours} Hours</span>
            </div>
          </div>

        </div>
      </div>

      <div className="flex justify-end gap-3 pt-4 border-t border-slate-100 mt-auto">
        <button type="button" onClick={onClose} className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg">Cancel</button>
        <button 
          type="submit" 
          disabled={loading}
          className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium disabled:opacity-50"
        >
          {loading ? 'Saving...' : initialData ? 'Update Course' : 'Create Course'}
        </button>
      </div>
    </form>
  );
};